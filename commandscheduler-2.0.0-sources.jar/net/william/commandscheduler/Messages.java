package net.william.commandscheduler;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_12087;
import net.minecraft.class_12094;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import com.mojang.brigadier.context.CommandContext;

public class Messages {

	public static class_5250 label(String name) {
		return class_2561.method_43470(" - " + name + ": ")
				.method_27694(s -> s.method_10982(true).method_10977(class_124.field_1080));
	}

	public static class_5250 styledCommand(String commandBase) {
		return class_2561.method_43470(" - /commandscheduler ")
				.method_27694(s -> s.method_10977(class_124.field_1080))
				.method_10852(class_2561.method_43470(commandBase).method_27694(s -> s.method_10977(class_124.field_1068)));
	}

	public static class_5250 arg(String name) {
		return arg(name, class_124.field_1056);
	}

	public static class_5250 arg(String name, class_124 format) {
		return class_2561.method_43470(name)
				.method_27694(s -> s.method_10978(true).method_10977(format));
	}

	public static void sendActivationStatus(CommandContext<class_2168> ctx, String id, boolean activated) {
		String senderName = ctx.getSource().method_9214();

		class_5250 msg = class_2561.method_43470("[CommandScheduler] ")
				.method_10852(class_2561.method_43470(senderName + " ").method_27694(s -> s.method_10977(class_124.field_1075)))
				.method_10852(class_2561.method_43470("has ").method_27694(s -> s.method_10977(class_124.field_1080)))
				.method_10852(class_2561.method_43470(activated ? "activated " : "deactivated ").method_27694(
						s -> s.method_10977(activated ? class_124.field_1060 : class_124.field_1061)))
				.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1054)));

		// Send to server console
		ctx.getSource().method_9211().method_43496(msg);

		// Send to all OPs
		ctx.getSource().method_9211().method_3760().method_14571().forEach(player -> {
			if (player.method_75004().hasPermission(new class_12087.class_12089(class_12094.method_75027(4)))) {
				player.method_7353(msg.method_27661().method_27694(s -> s.method_10977(class_124.field_1065)), false);
			}
		});
	}

	public static void sendInvalidID(CommandContext<class_2168> ctx) {
		ctx.getSource().method_9213(
				class_2561.method_43470("✖ Invalid ID or failed to update scheduler.")
						.method_27694(s -> s.method_10977(class_124.field_1061)));
	}

	public static void sendInvalidCommand(CommandContext<class_2168> ctx) {
		ctx.getSource().method_9213(
				class_2561.method_43470("✖ Command not allowed!")
						.method_27694(s -> s.method_10977(class_124.field_1061)));
	}

	public static void sendIDAlreadyExists(CommandContext<class_2168> ctx) {
		ctx.getSource().method_9213(
				class_2561.method_43470("✖ A scheduler with that ID already exists.")
						.method_27694(s -> s.method_10977(class_124.field_1061)));
	}

	public static void sendIdNotFound(CommandContext<class_2168> ctx, String id) {
		ctx.getSource().method_9213(
				class_2561.method_43470("✖ No scheduler found with ID ")
						.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1061))));
	}

	public static void sendClockBasedIdNotFound(CommandContext<class_2168> ctx, String id) {
		ctx.getSource().method_9213(
				class_2561.method_43470("✖ No clock-based scheduler found with ID ")
						.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1061))));
	}

	public static void sendReloadSuccess(CommandContext<class_2168> ctx) {
		String senderName = ctx.getSource().method_9214();

		class_5250 msg = class_2561.method_43470("[CommandScheduler] ")
				.method_10852(class_2561.method_43470(senderName + " ").method_27694(s -> s.method_10977(class_124.field_1075)))
				.method_10852(class_2561.method_43470("reloaded all configs.").method_27694(s -> s.method_10977(class_124.field_1080)));

		// Send to server console
		ctx.getSource().method_9211().method_43496(msg);

		// Send to all OPs
		ctx.getSource().method_9211().method_3760().method_14571().forEach(player -> {
			if (player.method_75004().hasPermission(new class_12087.class_12089(class_12094.method_75027(4)))) {
				player.method_7353(msg.method_27661().method_27694(s -> s.method_10977(class_124.field_1065)), false);
			}
		});
	}

	public static void sendSchedulerDetails(CommandContext<class_2168> ctx, Object cmd,
			String id) {
		class_5250 output = class_2561.method_43470("")
				.method_10852(class_2561.method_43470("\nDetails for scheduler: ")
						.method_27694(s -> s.method_10977(class_124.field_1065).method_10982(true)))
				.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1054)))
				.method_27693("\n");

		if (cmd instanceof Interval ic) {
			output.method_10852(class_2561.method_43470(" - Type: ")
					.method_27694(s -> s.method_10982(true).method_10977(class_124.field_1080)))
					.method_10852(class_2561.method_43470("Interval\n"));

			output.method_10852(label("Active")).method_10852(class_2561.method_43470(ic.isActive() + "\n"));

			output.method_10852(class_2561.method_43470(" - Interval: ")
					.method_27694(s -> s.method_10982(true).method_10977(class_124.field_1080)))
					.method_10852(class_2561.method_43470(ic.getInterval() + " " + ic.getUnit().name().toLowerCase()
							+ "\n"));

			output.method_10852(class_2561.method_43470(" - Command: ")
					.method_27694(s -> s.method_10982(true).method_10977(class_124.field_1080)))
					.method_10852(class_2561.method_43470(ic.getCommand()).method_27694(s -> s.method_10978(true)))
					.method_10852(class_2561.method_43470("\n"));

			if (ic.getDescription() != null && !ic.getDescription().isEmpty()) {
				output.method_10852(class_2561.method_43470(" - Description: ")
						.method_27694(s -> s.method_10982(true).method_10977(class_124.field_1080)))
						.method_10852(class_2561.method_43470(ic.getDescription())
								.method_27694(s -> s.method_10978(true)))
						.method_10852(class_2561.method_43470("\n"));
			}

		} else if (cmd instanceof ClockBased cc) {
			output.method_10852(class_2561.method_43470(" - Type: ")
					.method_27694(s -> s.method_10982(true).method_10977(class_124.field_1080)))
					.method_10852(class_2561.method_43470("Clock-Based\n"));

			output.method_10852(label("Active")).method_10852(class_2561.method_43470(cc.isActive() + "\n"));

			output.method_10852(class_2561.method_43470(" - Times: ")
					.method_27694(s -> s.method_10982(true).method_10977(class_124.field_1080)));
			List<int[]> times = cc.getTimes();
			for (int i = 0; i < times.size(); i++) {
				int[] time = times.get(i);
				String formatted = String.format("%02d:%02d", time[0], time[1]);
				output.method_10852(class_2561.method_43470(formatted));
				if (i < times.size() - 1)
					output.method_10852(class_2561.method_43470(", "));
			}
			output.method_10852(class_2561.method_43470("\n"));

			output.method_10852(class_2561.method_43470(" - Command: ")
					.method_27694(s -> s.method_10982(true).method_10977(class_124.field_1080)))
					.method_10852(class_2561.method_43470(cc.getCommand()).method_27694(s -> s.method_10978(true)))
					.method_10852(class_2561.method_43470("\n"));

			if (!cc.getDescription().isEmpty()) {
				output.method_10852(class_2561.method_43470(" - Description: ")
						.method_27694(s -> s.method_10982(true).method_10977(class_124.field_1080)))
						.method_10852(class_2561.method_43470(cc.getDescription())
								.method_27694(s -> s.method_10978(true)))
						.method_10852(class_2561.method_43470("\n"));
			}

		} else if (cmd instanceof AtBoot oc) {
			output.method_10852(class_2561.method_43470(" - Type: ")
					.method_27694(s -> s.method_10982(true).method_10977(class_124.field_1080)))
					.method_10852(class_2561.method_43470("Run Once at Boot\n"));

			output.method_10852(label("Active")).method_10852(class_2561.method_43470(oc.isActive() + "\n"));

			output.method_10852(class_2561.method_43470(" - Command: ")
					.method_27694(s -> s.method_10982(true).method_10977(class_124.field_1080)))
					.method_10852(class_2561.method_43470(oc.getCommand()).method_27694(s -> s.method_10978(true)))
					.method_10852(class_2561.method_43470("\n"));

			if (!oc.getDescription().isEmpty()) {
				output.method_10852(class_2561.method_43470(" - Description: ")
						.method_27694(s -> s.method_10982(true).method_10977(class_124.field_1080)))
						.method_10852(class_2561.method_43470(oc.getDescription())
								.method_27694(s -> s.method_10978(true)))
						.method_10852(class_2561.method_43470("\n"));
			}
		}
		ctx.getSource().method_9226(() -> output, false);
	}

	public static void sendAddedTimeMessage(CommandContext<class_2168> ctx, String timeArg, String id) {
		String senderName = ctx.getSource().method_9214();

		class_5250 msg = class_2561.method_43470("[CommandScheduler] ")
				.method_10852(class_2561.method_43470(senderName + " ").method_27694(s -> s.method_10977(class_124.field_1075)))
				.method_10852(class_2561.method_43470("added time ").method_27694(s -> s.method_10977(class_124.field_1080)))
				.method_10852(class_2561.method_43470(timeArg).method_27694(s -> s.method_10977(class_124.field_1075)))
				.method_10852(class_2561.method_43470(" to ").method_27694(s -> s.method_10977(class_124.field_1080)))
				.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1054)));

		// Send to server console
		ctx.getSource().method_9211().method_43496(msg);

		// Send to all OPs
		ctx.getSource().method_9211().method_3760().method_14571().forEach(player -> {
			if (player.method_75004().hasPermission(new class_12087.class_12089(class_12094.method_75027(4)))) {
				player.method_7353(msg.method_27661().method_27694(s -> s.method_10977(class_124.field_1065)), false);
			}
		});
	}

	public static void sendCreatedMessage(CommandContext<class_2168> ctx, String type, String id) {
		String senderName = ctx.getSource().method_9214();

		class_5250 msg = class_2561.method_43470("[CommandScheduler] ")
				.method_10852(class_2561.method_43470(senderName + " ").method_27694(s -> s.method_10977(class_124.field_1075)))
				.method_10852(class_2561.method_43470("created " + type + " scheduler with ID: ")
						.method_27694(s -> s.method_10977(class_124.field_1080)))
				.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1054)));

		// Send to server console
		ctx.getSource().method_9211().method_43496(msg);

		// Send to all OPs
		ctx.getSource().method_9211().method_3760().method_14571().forEach(player -> {
			if (player.method_75004().hasPermission(new class_12087.class_12089(class_12094.method_75027(4)))) {
				player.method_7353(msg.method_27661().method_27694(s -> s.method_10977(class_124.field_1065)), false);
			}
		});
	}

	public static void sendRenamedMessage(CommandContext<class_2168> ctx, String oldId, String newId) {
		String senderName = ctx.getSource().method_9214();

		class_5250 msg = class_2561.method_43470("[CommandScheduler] ")
				.method_10852(class_2561.method_43470(senderName + " ").method_27694(s -> s.method_10977(class_124.field_1075)))
				.method_10852(class_2561.method_43470("renamed ").method_27694(s -> s.method_10977(class_124.field_1080)))
				.method_10852(class_2561.method_43470(oldId).method_27694(s -> s.method_10977(class_124.field_1054)))
				.method_10852(class_2561.method_43470(" to ").method_27694(s -> s.method_10977(class_124.field_1080)))
				.method_10852(class_2561.method_43470(newId).method_27694(s -> s.method_10977(class_124.field_1054)));

		// Send to server console
		ctx.getSource().method_9211().method_43496(msg);

		// Send to all OPs (players with permission level >= 2)
		ctx.getSource().method_9211().method_3760().method_14571().forEach(player -> {
			if (player.method_75004().hasPermission(new class_12087.class_12089(class_12094.method_75027(4)))) {
				player.method_7353(msg.method_27661().method_27694(s -> s.method_10977(class_124.field_1065)), false);
			}
		});
	}

	public static void sendRemovedMessage(class_2168 source, String id) {
		String senderName = source.method_9214();

		class_5250 msg = class_2561.method_43470("[CommandScheduler] ")
				.method_10852(class_2561.method_43470(senderName + " ").method_27694(s -> s.method_10977(class_124.field_1075)))
				.method_10852(class_2561.method_43470("removed ").method_27694(s -> s.method_10977(class_124.field_1080)))
				.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1061)));

		// Send to server console
		source.method_9211().method_43496(msg);

		// Send to all OPs
		source.method_9211().method_3760().method_14571().forEach(player -> {
			if (player.method_75004().hasPermission(new class_12087.class_12089(class_12094.method_75027(4)))) {
				player.method_7353(msg.method_27661().method_27694(s -> s.method_10977(class_124.field_1065)), false);
			}
		});
	}

	public static void sendRemoveConfirmation(class_2168 source, String id) {
		source.method_9226(
				() -> class_2561.method_43470(" - Are you sure you want to remove ")
						.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1061)))
						.method_10852(class_2561.method_43470(
								"? Run the same command again within 30 seconds to confirm.")
								.method_27694(s -> s.method_10977(class_124.field_1080))),
				false);
	}

	public static void sendUpdatedDescription(CommandContext<class_2168> ctx, String id) {
		String senderName = ctx.getSource().method_9214();

		class_5250 msg = class_2561.method_43470("[CommandScheduler] ")
				.method_10852(class_2561.method_43470(senderName + " ").method_27694(s -> s.method_10977(class_124.field_1075)))
				.method_10852(class_2561.method_43470("updated description for ").method_27694(s -> s.method_10977(class_124.field_1080)))
				.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1054)));

		// Send to server console
		ctx.getSource().method_9211().method_43496(msg);

		// Send to all OPs
		ctx.getSource().method_9211().method_3760().method_14571().forEach(player -> {
			if (player.method_75004().hasPermission(new class_12087.class_12089(class_12094.method_75027(4)))) {
				player.method_7353(msg.method_27661().method_27694(s -> s.method_10977(class_124.field_1065)), false);
			}
		});
	}

	public static void sendRemovedTimeMessage(CommandContext<class_2168> ctx, String time, String id) {
		String senderName = ctx.getSource().method_9214();

		class_5250 msg = class_2561.method_43470("[CommandScheduler] ")
				.method_10852(class_2561.method_43470(senderName + " ").method_27694(s -> s.method_10977(class_124.field_1075)))
				.method_10852(class_2561.method_43470("removed time ").method_27694(s -> s.method_10977(class_124.field_1080)))
				.method_10852(class_2561.method_43470(time).method_27694(s -> s.method_10977(class_124.field_1075)))
				.method_10852(class_2561.method_43470(" from ").method_27694(s -> s.method_10977(class_124.field_1080)))
				.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1054)));

		// Send to server console
		ctx.getSource().method_9211().method_43496(msg);

		// Send to all OPs
		ctx.getSource().method_9211().method_3760().method_14571().forEach(player -> {
			if (player.method_75004().hasPermission(new class_12087.class_12089(class_12094.method_75027(4)))) {
				player.method_7353(msg.method_27661().method_27694(s -> s.method_10977(class_124.field_1065)), false);
			}
		});
	}

	public static void sendInvalidTimeFormat(CommandContext<class_2168> ctx) {
		ctx.getSource().method_9213(
				class_2561.method_43470("✖ Invalid time format. Use HH.MM (24h).")
						.method_27694(s -> s.method_10977(class_124.field_1061)));
	}

	public static void sendAlreadyActiveMessage(CommandContext<class_2168> ctx, String id) {
		ctx.getSource().method_9226(() -> class_2561.method_43470(" - ")
				.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1054)))
				.method_10852(class_2561.method_43470(" is already active.").method_27694(s -> s.method_10977(class_124.field_1080))),
				false);
	}

	public static void sendAlreadyInactiveMessage(CommandContext<class_2168> ctx, String id) {
		ctx.getSource().method_9226(() -> class_2561.method_43470(" - ")
				.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1054)))
				.method_10852(class_2561.method_43470(" is already inactive.")
						.method_27694(s -> s.method_10977(class_124.field_1080))),
				false);
	}

	public static int sendHelpMenu(CommandContext<class_2168> ctx, int page) {
		class_2168 source = ctx.getSource();
		source.method_9226(() -> class_2561.method_43470("\n"), false);

		switch (page) {
			case 1 -> sendHelpPage1(source);
			case 2 -> sendHelpPage2(source);
			case 3 -> sendHelpPage3(source);
			case 4 -> sendHelpPage4(source);
			default -> {
				source.method_9226(() -> class_2561.method_43470("§6[CommandScheduler Help Page " + page + "/4]"), false);
				source.method_9226(() -> class_2561.method_43470("This page doesn't exist."), false);
			}
		}
		return 1;
	}

	private static void sendHelpPage1(class_2168 source) {
		source.method_9226(() -> class_2561.method_43470("[CommandScheduler Help Page 1/4]")
				.method_27694(s -> s.method_10977(class_124.field_1065).method_10982(true)),
				false);

		source.method_9226(() -> Messages.styledCommand(""), false);

		source.method_9226(() -> Messages.styledCommand("help ")
				.method_10852(Messages.arg("[page]")), false);

		source.method_9226(() -> Messages.styledCommand("about"),
				false);

		source.method_9226(() -> Messages.styledCommand("reload"),
				false);

		source.method_9226(() -> class_2561.method_43470("For commands on creating new schedulers, go to page 2")
				.method_27694(s -> s.method_10977(class_124.field_1063)),
				false);
	}

	private static void sendHelpPage2(class_2168 source) {
		source.method_9226(() -> class_2561.method_43470("[CommandScheduler Help Page 2/4]")
				.method_27694(s -> s.method_10977(class_124.field_1065).method_10982(true)),
				false);

		source.method_9226(() -> Messages.styledCommand("add interval ")
				.method_10852(Messages.arg("<id>")).method_27693(" ")
				.method_10852(Messages.arg("<unit>")).method_27693(" ")
				.method_10852(Messages.arg("<interval>")).method_27693(" ")
				.method_10852(Messages.arg("<command>")),
				false);

		source.method_9226(() -> Messages.styledCommand("add clockbased ")
				.method_10852(Messages.arg("<id>")).method_27693(" ")
				.method_10852(Messages.arg("<command>")),
				false);

		source.method_9226(() -> Messages.styledCommand("add atboot ")
				.method_10852(Messages.arg("<id>")).method_27693(" ")
				.method_10852(Messages.arg("<command>")),
				false);

		source.method_9226(() -> class_2561.method_43470("For commands on listing details for schedulers, go to page 3")
				.method_27694(s -> s.method_10977(class_124.field_1063)),
				false);
	}

	private static void sendHelpPage3(class_2168 source) {
		source.method_9226(() -> class_2561.method_43470("[CommandScheduler Help Page 3/4]")
				.method_27694(s -> s.method_10977(class_124.field_1065).method_10982(true)),
				false);

		source.method_9226(() -> Messages.styledCommand("list active"), false);

		source.method_9226(() -> Messages.styledCommand("list inactive"), false);

		source.method_9226(() -> Messages.styledCommand("list atboot ")
				.method_10852(Messages.arg("[page]", class_124.field_1080)), false);

		source.method_9226(() -> Messages.styledCommand("list interval ")
				.method_10852(Messages.arg("[page]", class_124.field_1080)), false);

		source.method_9226(() -> Messages.styledCommand("list clockbased ")
				.method_10852(Messages.arg("[page]", class_124.field_1080)), false);

		source.method_9226(() -> Messages.styledCommand("details ")
				.method_10852(Messages.arg("<id>", class_124.field_1080)), false);

		source.method_9226(() -> class_2561.method_43470("For commands on modifying schedulers, go to page 4")
				.method_27694(s -> s.method_10977(class_124.field_1063)),
				false);
	}

	private static void sendHelpPage4(class_2168 source) {
		source.method_9226(() -> class_2561.method_43470("[CommandScheduler Help Page 4/4]")
				.method_27694(s -> s.method_10977(class_124.field_1065).method_10982(true)),
				false);

		source.method_9226(() -> Messages.styledCommand("activate ")
				.method_10852(Messages.arg("<id>")), false);

		source.method_9226(() -> Messages.styledCommand("deactivate ")
				.method_10852(Messages.arg("<id>")), false);

		source.method_9226(() -> Messages.styledCommand("rename ")
				.method_10852(Messages.arg("<id>")).method_27693(" ")
				.method_10852(Messages.arg("<new id>")), false);

		source.method_9226(() -> Messages.styledCommand("description ")
				.method_10852(Messages.arg("<id>")).method_27693(" ")
				.method_10852(Messages.arg("<description>")),
				false);

		source.method_9226(() -> Messages.styledCommand("addtime ")
				.method_10852(Messages.arg("<id>")).method_27693(" ")
				.method_10852(Messages.arg("<time>")),
				false);

		source.method_9226(() -> Messages.styledCommand("removetime ")
				.method_10852(Messages.arg("<id>")).method_27693(" ")
				.method_10852(Messages.arg("<time>")),
				false);

		source.method_9226(() -> Messages.styledCommand("remove ")
				.method_10852(Messages.arg("<id>")),
				false);

		source.method_9226(() -> class_2561.method_43470("For other questions, check modrinth or the github repository")
				.method_27694(s -> s.method_10977(class_124.field_1063)),
				false);

	}

	public static <T extends Scheduler> void sendList(class_2168 source,
			List<T> list, Boolean activeOnly) {

		List<T> filtered = new ArrayList<>();
		for (T cmd : list) {
			if (activeOnly == null || cmd.isActive() == activeOnly) {
				filtered.add(cmd);
			}
		}

		if (filtered.isEmpty()) {
			String msg = activeOnly == null ? "§8(no schedulers found)"
					: activeOnly ? "§8(no active schedulers found)"
							: "§8(no inactive schedulers found)";
			source.method_9226(() -> class_2561.method_43470(msg), false);
			return;
		}

		for (int i = 0; i < Math.min(4, filtered.size()); i++) {
			T cmd = filtered.get(i);
			String id = cmd.getID();
			boolean isActive = cmd.isActive();

			source.method_9226(() -> class_2561.method_43470(" - ")
					.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1054)))
					.method_10852(class_2561.method_43470(" (" + (isActive ? "active" : "inactive") + ")")
							.method_27694(s -> s.method_10977(class_124.field_1080))),
					false);
		}

		if (filtered.size() > 4) {
			int more = filtered.size() - 4;
			source.method_9226(() -> class_2561.method_43470("and " + more + " more...")
					.method_27694(s -> s.method_10977(class_124.field_1063).method_10978(true)), false);
		}
	}

	public static <T extends Scheduler> void sendListOfType(class_2168 source, List<T> fullList, int page,
			String title, int perPage) {
		int total = fullList.size();

		// If the list is empty, show "no schedulers found" message and return
		if (total == 0) {
			source.method_9226(() -> class_2561.method_43470("\n§6[" + title + "]"), false);
			source.method_9226(() -> class_2561.method_43470("§8(no schedulers found)"), false);
			return;
		}

		int maxPages = (int) Math.ceil((double) total / perPage);
		if (page < 1 || page > maxPages) {
			source.method_9226(() -> class_2561.method_43470("§6[" + title + " Page " + page + "/" + maxPages + "]"), false);
			source.method_9226(() -> class_2561.method_43470("This page doesn't exist."), false);
			return;
		}

		source.method_9226(() -> class_2561.method_43470("\n§6[" + title + " Page " + page + "/" + maxPages + "]"), false);

		int start = (page - 1) * perPage;
		int end = Math.min(start + perPage, total);

		for (int i = start; i < end; i++) {
			T cmd = fullList.get(i);
			String id = cmd.getID();
			boolean isActive = cmd.isActive();

			source.method_9226(() -> class_2561.method_43470(" - ")
					.method_10852(class_2561.method_43470(id).method_27694(s -> s.method_10977(class_124.field_1054)))
					.method_10852(class_2561.method_43470(" (" + (isActive ? "active" : "inactive") + ")")
							.method_27694(s -> s.method_10977(class_124.field_1080))),
					false);
		}
	}

	public static void sendListHeader(class_2168 source, String title) {
		source.method_9226(() -> class_2561.method_43470("\n§6[" + title + "]"), false);
	}

}
